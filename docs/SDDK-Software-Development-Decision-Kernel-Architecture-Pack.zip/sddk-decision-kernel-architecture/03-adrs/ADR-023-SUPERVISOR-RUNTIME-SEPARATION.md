# ADR-023-SUPERVISOR-RUNTIME-SEPARATION — Separate cognitive Supervisor from deterministic runtime

**Status:** Accepted


## Decision
The Supervisor owns goal interpretation, ambiguous planning, replanning and escalation. The runtime owns scheduling, retries, timeouts, joins, locks, budgets, idempotency, circuit breakers and policy enforcement.

## Rationale
Using LLM calls for deterministic control wastes tokens and makes recovery non-reproducible. Conversely, encoding ambiguous planning in a finite-state machine makes the system brittle.

## Rule of thumb
**LLM decides WHAT; runtime decides HOW, WHEN and WHETHER IT IS ALLOWED.**

## Consequences
The Supervisor becomes a privileged cognitive behavior, not the process that manually drives every call.
