# ADR-024-GENERIC-WORKFLOW-IR — Replace closed SDD phase semantics with a generic Workflow IR

**Status:** Accepted


## Context
`Phase` and `CyclePath` encode a useful SDD lifecycle but prevent non-SDD workflows from being first-class.

## Decision
Introduce versioned `WorkflowDefinition`, generic node kinds, typed edges and policies. Keep SDD-specific phase names in `sddk-sdd`.

## Compatibility
Compile legacy paths/manifests into Workflow IR during migration.

## Consequences
Incident, UAT, security, release and research workflows can reuse the same runtime without adding values to a universal enum.
