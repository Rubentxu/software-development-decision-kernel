# ADR-035-EVALUATION-FEEDBACK — Use execution history for explainable routing evaluation

**Status:** Accepted


## Decision
Persist outcome metrics by capability/model/provider/agent/route and allow routing policies to consume aggregate historical statistics. Historical score is an input, not an opaque autonomous authority.

## Guardrails
- minimum sample thresholds;
- confidence intervals or uncertainty marker;
- no auto-promotion solely from tiny samples;
- retain deterministic policy constraints;
- expose why a route was selected.

## Consequences
The system can improve from real usage while remaining inspectable and overrideable.
