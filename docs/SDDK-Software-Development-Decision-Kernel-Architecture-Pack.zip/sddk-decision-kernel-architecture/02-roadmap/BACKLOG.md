# Product / Architecture Backlog

## Epic A — Kernel convergence
- [ ] Focused ports replacing `Ledger` usage.
- [ ] Composition root outside application core.
- [ ] Architecture dependency tests.
- [ ] Compatibility facade tests.

## Epic B — Event nervous system
- [ ] Canonical event taxonomy.
- [ ] Host event normalization.
- [ ] Event Journal projection.
- [ ] Correlation/causation visualization.

## Epic C — Workflow runtime v2
- [ ] Generic node kinds.
- [ ] NodeRun/Attempt split.
- [ ] pause/resume/cancel.
- [ ] subworkflow and join.
- [ ] compensation.

## Epic D — Agent Execution Control Plane
- [ ] AgentHost abstraction.
- [ ] OpenCode adapter.
- [ ] model/provider routing.
- [ ] health registry.
- [ ] circuit breaker.
- [ ] failover policy.
- [ ] budget policy.

## Epic E — Reactive supervisor
- [ ] Behavior engine.
- [ ] reaction levels.
- [ ] OrchestratorSignal.
- [ ] SupervisorBehavior.
- [ ] Critic/Adjudicator optional behaviors.

## Epic F — Context intelligence
- [ ] ContextCapsule.
- [ ] context delta.
- [ ] staleness.
- [ ] negative knowledge.
- [ ] recovery handoff.

## Epic G — Cockpit
- [ ] snapshot projection schema.
- [ ] overview.
- [ ] journal.
- [ ] workflow timeline.
- [ ] provider/model health.
- [ ] graph lens.
- [ ] static HTML build/open/watch.

## Epic H — UAT
- [ ] bounded context extraction.
- [ ] defect/retest/signoff.
- [ ] change impact.
- [ ] observability correlation.

## Epic I — Packs
- [ ] SDD pack.
- [ ] UAT pack.
- [ ] Incident pack.
- [ ] Pack validation.

## Epic J — Learning & evaluation
- [ ] capability golden sets.
- [ ] outcome metrics.
- [ ] route score simulation.
- [ ] A/B fork/replay.

## Epic K — Software supply chain
- [ ] SBOM object model.
- [ ] provenance/attestation refs.
- [ ] artifact lifecycle graph.
- [ ] release policy gates.
