# ROADMAP

## Estrategia

Evitar introducir simultáneamente workflow v2, supervisor, graph, UAT y UI. La secuencia minimiza riesgo arquitectónico y produce valor observable en cada etapa.

## Phase 0 — Baseline & Architecture Ratchet

**Objetivo:** congelar y medir el estado actual.

- generar mapa de dependencias de crates/modules;
- tests que detecten `engine -> storage`;
- inventario de usos del super-port `Ledger`;
- inventario de `Phase` y `CyclePath` fuera del pack SDD;
- baseline de event types actuales;
- baseline de UAT v3/v4;
- comando `sddk check-arch` inicial.

**Exit:** CI puede detectar nuevas violaciones aunque todavía existan legacy exceptions explícitas.

## Phase 1 — Hexagonal Convergence

- sacar `Engine::from_path()` al composition root;
- introducir focused ports;
- application services sin adapters concretos;
- testkit de in-memory fakes;
- separar `sddk-domain` de dependencias operacionales evitables;
- mantener facade `Engine` sólo para compatibilidad.

**Exit:** application core compila/testea sin SQLite.

## Phase 2 — Canonical Event Ledger

- definir EventEnvelope vNext compatible;
- event append/read/subscribe ports;
- normalización de eventos internos;
- correlation/causation obligatorios para execution paths;
- projections rebuildables;
- Event Journal mínimo.

**Exit:** una sesión puede reconstruirse desde eventos.

## Phase 3 — Workflow Runtime v2

- `WorkflowDefinition`, `WorkflowRun`, `NodeRun`, `Attempt`;
- node kinds genéricos;
- DAG/FSM transitions deterministas;
- retries/timeouts/cancel/pause/resume;
- subworkflows;
- adapter de `Phase/CyclePath` legacy.

**Exit:** SDD actual corre sobre Workflow v2 sin semántica SDD dentro del kernel.

## Phase 4 — AgentHost + OpenCode Spike → Production Adapter

- `AgentHostEventAdapter`;
- `AgentHostControl`;
- OpenCode session/event integration;
- usage/tokens/model/provider capture;
- normalized `session.error`, idle, tool events;
- context injection.

**Exit:** una ejecución OpenCode produce eventos canónicos y puede recibir comandos/contexto desde SDDK.

## Phase 5 — Execution Router & Provider Failover

- failure taxonomy;
- provider health registry;
- circuit breakers;
- route scoring;
- attempt recovery;
- model/provider/host fallback;
- budgets.

**Demo obligatoria:** `Claude quota exhausted → GPT resumes same NodeRun`.

## Phase 6 — Reactive Behaviors & Supervisor

- reaction policy 0/1/2;
- deterministic behavior runtime;
- `OrchestratorSignal`;
- supervisor como cognitive behavior privilegiado;
- no recursive delegation default;
- critic/adjudicator para high-risk.

**Exit:** la mayoría de fallos operacionales no consumen una llamada LLM para decidir retry/failover.

## Phase 7 — Context Compiler

- ContextCapsule v1;
- must-read/on-demand;
- deltas;
- negative knowledge;
- staleness;
- read tracing;
- recovery capsule entre attempts.

## Phase 8 — Active Graph Projection

- typed graph projection;
- causal trace;
- query/lens API;
- `sddk why`;
- replay and rebuild;
- operational routing statistics graph.

## Phase 9 — Static Control Plane

- `control-plane.sqlite` projections;
- Event Journal;
- session/workflow timeline;
- provider/model health;
- agent/model usage;
- causal graph;
- `sddk cockpit build/open/watch`;
- self-contained HTML, zero CDN/fetch/server.

## Phase 10 — UAT Bounded Context Pack

- extract UAT domain/app/adapters/web;
- campaign/run/defect/retest/waiver/signoff;
- change-impact → minimal retest set;
- evidence and observability correlation;
- release decision gates.

## Phase 11 — Packs & Multiple Workflows

Probar el runtime con tres packs antes de ampliar catálogo:

1. `sddk-sdd`;
2. `sddk-uat`;
3. `sddk-incident`.

Después: security, release, bugfix, upgrade, migration, research.

## Phase 12 — Fork / Replay / A-B / Evaluation

- fork workflow state;
- route/model/prompt/policy A-B;
- golden capability datasets;
- success/cost/latency/retry/human intervention metrics;
- feedback controlado para routing.

## Phase 13 — Supply Chain & Provenance

- SBOM references;
- artifact origin;
- build provenance/attestations;
- lifecycle state;
- package/image/source graph edges;
- policy gates before release.

## Phase 14 — Quality Ratchets

Convertir warnings arquitectónicos y operational smells gradualmente en errores de CI.
