# Migration Plan from Current SDDK

## Qué conservar

- EventEnvelope/provenance/correlation foundations.
- ContextReadRecord como base de trazabilidad de lectura.
- graph projection idea y rebuildability.
- UAT v3/v4: executor kinds, evidence bundle, oracles, machine/human separation, review triggers, plan approval.
- pack discovery direction.
- governed capability flow.
- model registration/tiering.
- CLI y manifests como compatibility surface.

## Qué refactorizar

### 1. `Ledger`
De aggregate super-port a puertos estrechos.

### 2. `Engine`
Mantener temporalmente fachada, pero delegar en application services.

### 3. `Engine::from_path()`
Mover a CLI/host composition root.

### 4. `sddk-engine -> sddk-storage`
Eliminar dependencia de producción; adapters se inyectan.

### 5. `Phase`/`CyclePath`
Conservar sólo en compatibility layer o pack SDD.

```text
Legacy CyclePath::AFull
 → SddPackCompiler
 → WorkflowDefinition v2
```

### 6. UAT giant module
No mover el fichero sin más. Separar semántica, application ports, adapters y rendering.

### 7. Recursive agent delegation
Convertir agentes de fase en workers. Delegación sólo desde Supervisor o sub-supervisores declarados.

## Estrategia Strangler

```text
Legacy API
   │
   ▼
Compatibility Facade
   │
   ▼
New Application Core
```

No eliminar CLI/formatos antiguos hasta que fixtures de compatibilidad demuestren equivalencia.

## Secuencia segura

1. Introducir ports v2 y adapters que envuelven implementaciones actuales.
2. Cambiar cada caso de uso de `Ledger` a focused port.
3. Introducir Workflow v2 detrás de APIs existentes.
4. Compilar workflows legacy a Workflow v2.
5. Introducir Event Journal sin cambiar comportamiento.
6. Añadir AgentHost/OpenCode como feature opt-in.
7. Añadir failover en modo observe/simulate antes de auto-actuar.
8. Habilitar automatic failover por policy.
9. Extraer UAT.
10. Eliminar legacy types cuando usage = 0.

## Safety modes

Para routing/failover:

```text
observe   → detecta y registra, no cambia ejecución
suggest   → propone route alternativa, requiere confirmación
auto      → aplica policy automáticamente
```

Esto permite desplegar el control plane progresivamente.
