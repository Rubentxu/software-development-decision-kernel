# Control Flows

## 1. Goal → Workflow

```mermaid
sequenceDiagram
  participant U as User
  participant A as App
  participant S as Supervisor
  participant W as Workflow Runtime
  U->>A: goal
  A->>S: interpret(goal, context)
  S-->>A: WorkflowPlan / DefinitionRef
  A->>W: start(definition, inputs)
  W-->>A: WorkflowRunStarted
```

## 2. Node execution

```mermaid
sequenceDiagram
  participant W as Workflow Runtime
  participant R as Execution Router
  participant C as Context Compiler
  participant H as AgentHost
  participant V as Verifier
  W->>R: execute(NodeRun)
  R->>C: compile context
  C-->>R: ContextCapsule
  R->>H: execute(route, capsule)
  H-->>R: events/result
  R->>V: verify(result,evidence)
  V-->>W: verification
```

## 3. Reactive provider failure

```mermaid
sequenceDiagram
  participant H as OpenCode Adapter
  participant L as Ledger
  participant B as ProviderHealthBehavior
  participant R as Execution Router
  participant S as Supervisor
  H->>L: provider.quota.exhausted
  L->>B: event
  B->>L: provider.circuit.opened
  B->>L: execution.route.invalidated
  alt alternate route deterministic
    B->>R: retry with compatible route
  else ambiguity / policy choice
    B->>L: orchestrator.signal.created
    L->>S: signal
    S->>R: replan route
  end
```

## 4. Cognitive signal injection

La inyección al IDE no usa texto de log bruto. Se compila:

```text
Canonical Event
 + projection state
 + current workflow/node
 + previous attempt progress
 + allowed actions
 + route candidates
 → OrchestratorSignal
 → ContextCapsule delta
 → AgentHostControl.send_context/prompt
```

## 5. Governed effect

```mermaid
flowchart LR
  A[Agent Proposal] --> P[Policy]
  P -->|deny| D[Denied Event]
  P -->|approval required| H[Human Approval]
  P -->|allow| C[Scoped Capability]
  H -->|approve| C
  C --> E[Execute effect]
  E --> V[Verify postcondition]
  V --> R[Receipt]
  R --> L[(Ledger)]
```
