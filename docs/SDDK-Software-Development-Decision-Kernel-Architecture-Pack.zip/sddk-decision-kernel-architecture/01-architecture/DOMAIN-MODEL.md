# Domain Model

## Aggregates / logical entities

### WorkflowDefinition
Definición versionada e inmutable de un workflow.

### WorkflowRun
Instancia de una definición con inputs, state y correlation id.

### NodeRun
Unidad lógica de trabajo dentro del workflow.

### Attempt
Intento físico de ejecutar un NodeRun usando una route concreta.

### AgentExecution
Ejecución de un logical agent; puede estar dentro de un Attempt.

### Capability
Acción semántica disponible para el planner/router.

### ExecutionRoute
Selección concreta de host, agent profile, model, provider y credenciales.

### ContextCapsule
Contrato de contexto compilado para una ejecución.

### Evidence
Artefacto que soporta una afirmación/verificación/aceptación.

### Decision
Conclusión explícita con rationale, confidence y supporting evidence refs.

### Receipt
Registro verificable de un efecto gobernado.

### ProviderHealth
Estado derivado: healthy/degraded/open/unknown, con razón y ventana temporal.

### Budget
Límites jerárquicos por workspace/workflow/node/attempt.

### HumanDecision
Approval/rejection/waiver/acceptance/signoff con actor y evidence refs.

## Relaciones importantes

```mermaid
classDiagram
  WorkflowDefinition "1" --> "*" WorkflowRun
  WorkflowRun "1" --> "*" NodeRun
  NodeRun "1" --> "*" Attempt
  Attempt --> ExecutionRoute
  Attempt --> ContextCapsule
  Attempt --> AgentExecution
  AgentExecution --> Artifact
  AgentExecution --> Evidence
  Decision --> Evidence
  Receipt --> Evidence
  ExecutionRoute --> ProviderHealth
  NodeRun --> HumanDecision
```

## Estados: evitar mega-enums globales

El estado debe estar cerca del aggregate correspondiente.

### NodeRunState

```text
Pending
Ready
Running
Waiting
Verifying
Succeeded
Failed
Cancelled
Compensating
Compensated
```

### AttemptState

```text
Created
Starting
Running
Interrupted
FailedInfrastructure
FailedTask
Succeeded
Aborted
```

### ProviderRouteState

```text
Unknown
Healthy
Degraded
CircuitOpen
HalfOpen
Disabled
```

## Distinción crítica

```text
Task failure != Infrastructure/provider failure
```

Un test que falla puede ser el resultado correcto del agente tester. Un 429 del proveedor es un fallo de infraestructura de ejecución. No deben compartir semantics ni retry policy.
