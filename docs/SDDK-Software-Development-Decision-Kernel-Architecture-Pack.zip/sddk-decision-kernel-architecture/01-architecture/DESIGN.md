# DESIGN — SDDK Software Development Decision Kernel

## 1. Objetivo

Transformar SDDK en un kernel genérico de control para workflows de ingeniería de software ejecutados por humanos, agentes, herramientas deterministas y servicios externos.

## 2. Arquitectura lógica

```mermaid
flowchart TB
  U[User / API / CLI] --> APP[Application Services]
  APP --> SUP[Supervisor]
  APP --> WF[Workflow Runtime]
  WF --> RX[Reactive Runtime]
  RX --> ROUTER[Execution Router]
  SUP --> ROUTER
  ROUTER --> CAP[Capability Registry]
  ROUTER --> HOST[AgentHost Port]
  ROUTER --> HUMAN[HumanReview Port]
  HOST --> OC[OpenCode Adapter]
  HOST --> IDE2[Other IDE Adapter]
  ROUTER --> GOV[Governed Effects]
  GOV --> TOOLS[Git / FS / CI / Browser / MCP]
  OC --> NORM[Host Event Normalizer]
  IDE2 --> NORM
  TOOLS --> NORM
  NORM --> LEDGER[(Event Ledger)]
  WF --> LEDGER
  SUP --> LEDGER
  LEDGER --> GRAPH[Active Graph Projection]
  LEDGER --> OPS[Operational Projections]
  GRAPH --> CTX[Context Compiler]
  OPS --> CTX
  CTX --> SUP
  CTX --> ROUTER
  LEDGER --> COCKPIT[Static Cockpit]
```

## 3. Capas

### `sddk-kernel`
Semántica estable:

- IDs y value objects;
- events/envelopes;
- workflow contracts;
- capability contracts;
- policy decisions;
- evidence references;
- receipts;
- context capsule schema;
- error taxonomy.

No depende de SQLite, OpenCode, Git, HTTP ni modelos concretos.

### `sddk-app`
Casos de uso:

- start/resume/cancel workflow;
- ingest external event;
- route execution;
- request approval;
- compile context;
- query causal explanation;
- build cockpit snapshot.

### `sddk-orchestration`

- workflow runtime;
- node scheduler;
- supervisor service;
- reaction policies;
- behaviors;
- execution router;
- retry/failover policies;
- budget manager.

### `sddk-context`

- context compiler;
- artifact/context selectors;
- delta/staleness;
- negative knowledge;
- read tracing;
- context budget.

### `sddk-ledger`

- append-only store;
- optimistic concurrency;
- event subscriptions;
- checkpoints;
- projections;
- snapshots opcionales.

### `sddk-graph`

- typed nodes/edges;
- causal relationships;
- operational knowledge graph;
- graph views/lenses;
- replay/rebuild.

### `adapters/*`

- `opencode`;
- `sqlite`;
- `filesystem`;
- `git`;
- `mcp`;
- `http`;
- `browser`;
- `computer-use`;
- `llama-cpp` si se necesita acceso directo.

### `packs/*`

- `sdd`;
- `uat`;
- `incident`;
- `security`;
- `release`;
- `dependency-upgrade`;
- `db-migration`;
- `research`.

## 4. Control flow

### Normal path

```text
Goal
 → WorkflowDefinition selected/compiled
 → WorkflowRun created
 → ready NodeRun
 → capability resolved
 → execution route selected
 → ContextCapsule compiled
 → AgentHost executes
 → normalized events
 → result/evidence
 → verifier
 → node transition
 → next nodes
```

### Reactive path

```text
External/Internal Event
 → normalize
 → append ledger
 → projection update
 → ReactionPolicy
      ├─ OBSERVE
      ├─ DETERMINISTIC_BEHAVIOR
      └─ COGNITIVE_SIGNAL
 → behavior/supervisor
 → new command/effect
 → new events
```

### Provider failover

```text
Attempt A
 → provider error
 → failure classifier
 → ProviderHealthBehavior
 → circuit opened
 → route invalidated
 → ExecutionRouter selects B
 → ContextCapsule recovery delta
 → Attempt B
 → verify
```

## 5. Separación Supervisor / Runtime

El Supervisor NO implementa:

- locks;
- retry timers;
- queue ordering;
- DAG transitions;
- circuit breakers;
- token accounting;
- idempotency;
- policy enforcement.

El Supervisor SÍ hace:

- interpretar objetivos;
- elegir/compilar estrategia;
- resolver ambigüedad;
- replanificar;
- priorizar cuando existen varias soluciones válidas;
- decidir escalado/human gate;
- razonar con incertidumbre global.

## 6. Workflow IR genérico

Eliminar `Phase` como concepto universal del kernel.

```rust
struct WorkflowDefinition {
    id: WorkflowId,
    version: Version,
    inputs: SchemaRef,
    nodes: Vec<WorkflowNode>,
    edges: Vec<WorkflowEdge>,
    policies: Vec<PolicyRef>,
    outputs: SchemaRef,
}

enum WorkflowNodeKind {
    AgentTask,
    Capability,
    Decision,
    Gate,
    HumanApproval,
    Parallel,
    Join,
    SubWorkflow,
    WaitForEvent,
    Verification,
    Compensation,
}
```

`Explore`, `Specify`, `Design` etc. siguen existiendo dentro del pack SDD.

## 7. Execution identity

```text
WorkflowRun
└── NodeRun
    ├── Attempt #1: OpenCode + Claude → quota exhausted
    └── Attempt #2: OpenCode + GPT → success
```

La identidad del trabajo es `NodeRun`; modelo/host/proveedor son atributos del `Attempt`.

## 8. Reliability

- event append idempotency key;
- execution idempotency key;
- lease para NodeRun si existe concurrencia;
- retry policies declarativas;
- timeout por capability;
- circuit breaker por provider/model/credential route;
- compensation node para efectos reversibles;
- replay desde ledger.

## 9. Seguridad

Nunca entregar un “toolbox” irrestricto al agente.

```text
Agent Proposal
 → Policy evaluation
 → optional human approval
 → scoped capability token
 → adapter effect
 → postcondition verification
 → immutable receipt
```

## 10. Estrategia de modularización

No hacer un big-bang de crates. Orden:

1. introducir interfaces estrechas dentro de la estructura actual;
2. eliminar dependencias prohibidas;
3. mover composition roots a hosts;
4. extraer bounded contexts grandes;
5. separar crates cuando haya dependencia unidireccional demostrable.

## 11. Compatibilidad

Durante la migración:

```text
Legacy Phase/CyclePath
       ↓ adapter/compiler
WorkflowDefinition v2
```

El CLI y los manifests antiguos pueden seguir funcionando mientras el kernel interno deja de depender de las enums cerradas.
