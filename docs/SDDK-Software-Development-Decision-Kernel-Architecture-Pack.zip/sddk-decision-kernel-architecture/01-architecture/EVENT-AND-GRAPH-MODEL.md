# Event Ledger & Active Graph Model

## Regla de autoridad

```text
Event Ledger = historia operacional autoritativa
Active Graph = proyección reconstruible
Cockpit = proyección de lectura
```

## Event Envelope

El envelope debe conservar la dirección ya iniciada por SDDK (`actor`, hashes, subjects, evidence refs, correlation/causation, cycle/workflow identifiers) y generalizarla.

```yaml
id: evt-01J...
type: provider.quota.exhausted
occurred_at: 2026-08-19T12:08:32+02:00
actor:
  kind: agent_host
  id: opencode-local
correlation_id: wf-174
causation_id: evt-previous
subjects:
  - node-run:nr-32
  - provider:anthropic
  - model:claude-x
payload:
  status_code: 429
  retryable: false
  quota_kind: weekly
provenance:
  host_event_type: session.error
```

## Canonical event pipeline

```text
Raw Host Event
 → Adapter normalization
 → CanonicalEvent
 → validation
 → append
 → projection fanout
 → reaction policy
```

## ActiveGraph-like semantics

El grafo contiene **qué sabe el sistema y cómo se relaciona**, no sustituye el workflow engine.

### Node types

- Goal
- WorkflowDefinition
- WorkflowRun
- NodeRun
- Attempt
- LogicalAgent
- Capability
- AgentHost
- Provider
- Model
- Artifact
- Evidence
- Decision
- ContextCapsule
- HumanDecision
- Failure
- Receipt
- Policy
- Requirement
- UatScenario/UatRun

### Edge examples

```text
Goal --spawned--> WorkflowRun
WorkflowRun --contains--> NodeRun
NodeRun --attempted-by--> Attempt
Attempt --routed-to--> Model
Attempt --executed-on--> AgentHost
Attempt --used-context--> ContextCapsule
Attempt --failed-by--> Failure
Failure --opened-circuit-for--> Provider
Decision --supported-by--> Evidence
Evidence --derived-from--> Artifact
UatRun --validates--> Requirement
```

## Behaviors

Los behaviors son consumidores reactivos del ledger/projection state.

```text
Event + current projection
       ↓
Behavior predicate
       ↓
Command / Proposal / New Event
```

Un behavior debe ser idempotente respecto al event id que consume.

## Replay

Recrear projections:

```text
truncate projection
→ replay event ledger in order
→ deterministic state
```

Reejecutar side effects **no** forma parte de un replay de proyección. Los receipts previenen confundir reconstrucción con ejecución.

## Fork

Un fork crea una rama lógica desde un evento/version point con un nuevo fork id. Permite probar:

- modelos distintos;
- prompts distintos;
- políticas distintas;
- workflow definitions distintas.

El diff compara nuevos eventos/projections, no modifica la historia original.
