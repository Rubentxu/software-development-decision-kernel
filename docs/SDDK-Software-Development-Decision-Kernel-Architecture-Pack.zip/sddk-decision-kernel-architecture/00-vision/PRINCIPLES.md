# Architectural & Product Principles

## P1 — Git y el Event Ledger tienen autoridad explícita
Git conserva la autoridad sobre el código. El Event Ledger conserva la historia operacional de SDDK. Las projections y el graph se reconstruyen.

## P2 — Agente lógico ≠ modelo ≠ proveedor ≠ IDE
No codificar identidades como `architect = claude`. El agente representa una capacidad/rol; el router decide el backend de ejecución.

## P3 — LLM decide WHAT; runtime decide HOW/WHEN/IF ALLOWED
Scheduling, retries, circuit breakers, idempotencia, concurrencia, budgets y políticas son deterministas.

## P4 — No convertir cada evento en prompt
Primero clasificar. Observe → deterministic behavior → cognitive signal.

## P5 — Toda reacción importante deja evento
Si no queda evento, no existe operacionalmente.

## P6 — El graph no es source of truth
Es una proyección temporal y causal derivada del ledger.

## P7 — Contexto mínimo, relevante y trazable
Evitar context dumps. Context Capsules con must-read, on-demand, deltas, staleness y negative knowledge.

## P8 — Side effects gobernados
Los agentes proponen; una capability autorizada ejecuta; postconditions verifican; receipts acreditan.

## P9 — Failover conserva la identidad lógica del trabajo
Cambiar proveedor genera un nuevo `Attempt`, no un nuevo trabajo independiente.

## P10 — Verificación independiente
El actor que produce no debe ser la única autoridad que certifica su resultado.

## P11 — Human-in-the-loop es una primitive, no un parche
Approval, review, UAT acceptance y sign-off son nodos explícitos del workflow.

## P12 — Packs, no hardcoding del dominio
SDD/UAT/security/incident/release deben vivir sobre contratos extensibles.

## P13 — Local-first por defecto
Ledger, graph, metrics y cockpit deben funcionar sin servicio remoto obligatorio.

## P14 — El Control Plane debe poder abrirse sin servidor
Generación HTML autocontenida desde persistencia; servidor opcional sólo para experiencias que realmente lo necesiten.

## P15 — La arquitectura se protege con fitness functions
Los ADR no bastan. Dependencias, puertos, side effects y reglas de delegación se verifican automáticamente.

## P16 — Aprender de la ejecución real
Routing y políticas pueden aprovechar estadísticas históricas, pero siempre con explicabilidad y posibilidad de override.
