# Study & Adoption Guide

## Track A — Understand the idea (60–90 min)
1. `NAMING.md`
2. `PRODUCT-VISION.md`
3. `PRINCIPLES.md`
4. `../01-architecture/DESIGN.md`
5. `../01-architecture/EVENT-AND-GRAPH-MODEL.md`

Goal: understand why SDDK becomes a Decision Kernel and why Event Ledger + reactive graph + deterministic runtime is the central model.

## Track B — Plan repository evolution
1. `../02-roadmap/MIGRATION-PLAN.md`
2. `../09-implementation/ARCHITECTURE-FITNESS-FUNCTIONS.md`
3. `../09-implementation/REPOSITORY-TARGET-LAYOUT.md`
4. ADR-032 focused ports (see ADR index)
5. Workflow Runtime spec.

Goal: make architectural convergence before adding more intelligence.

## Track C — Solve provider quota/failover first
1. AgentHost Protocol.
2. Execution Router.
3. Provider Health & Failover.
4. Reactive Behaviors.
5. `../08-spikes/SPIKE-001-OPENCODE-EVENT-CONTROL.md`
6. `../08-spikes/SPIKE-002-PROVIDER-FAILOVER.md`

Goal: demonstrate `same NodeRun → failed Attempt A → successful Attempt B`.

## Track D — Build independent visibility
1. Event Taxonomy.
2. Observability & Usage.
3. Cockpit spec.
4. `../06-control-plane/EVENT-JOURNAL.md`
5. `../06-control-plane/MOLDABLE-VIEWS.md`
6. Static Cockpit spike.

## Track E — Advanced agent intelligence
1. Supervisor Runtime.
2. Context Capsules.
3. Active Graph model.
4. Agent Evaluation.
5. Fork/Replay/Diff.

## Track F — Product domains
Study UAT, Packs and Supply Chain only after kernel/runtime seams are sound.

## Recommended first implementation milestone
Do **not** start with graph UI. First deliver:

```text
focused ports
→ canonical events
→ WorkflowRun/NodeRun/Attempt
→ OpenCode adapter
→ injected quota failure
→ failover
→ Journal entry
```

That vertical slice validates the architecture and directly solves a real pain point.

