# PRD — SDDK Software Development Decision Kernel

## Product statement
SDDK is a local-first, event-sourced, reactive control plane that coordinates software-engineering workflows across humans, agentic IDEs, models, providers and deterministic tools while preserving decisions, evidence, provenance and operational history.

## Primary users
- software engineers using one or more agentic IDEs;
- platform/DevOps/AI engineers governing agent workflows;
- technical leads reviewing decisions and evidence;
- QA/UAT participants performing guided acceptance;
- teams that need reproducibility, supply-chain provenance and controlled automation.

## Core jobs to be done
1. Continue important work when a model/provider/IDE route fails or exhausts quota.
2. Understand what ran during a work session and why.
3. Execute different engineering workflows on one reusable runtime.
4. Give agents only the context and authority they actually require.
5. Validate outcomes with deterministic checks, agents and humans.
6. Reconstruct, replay, fork and compare execution histories.
7. Inspect all of this locally without operating another server.

## Functional requirements

### FR1 Workflow runtime
Generic durable workflow definitions, node runs, attempts, parallelism, waits, approvals, retries, cancellation, subworkflows and compensation.

### FR2 Supervisor
Cognitive goal interpretation/replanning separated from deterministic orchestration.

### FR3 Multi-host agent execution
Bidirectional adapters for agentic IDEs; OpenCode is first reference integration.

### FR4 Resilient routing
Logical agent independent from host/provider/model; health-aware route selection and failover.

### FR5 Reactive events
Canonical Event Ledger, reaction levels, deterministic behaviors and cognitive signals.

### FR6 Context compiler
Context Capsules, deltas, staleness, read tracing and negative knowledge.

### FR7 Evidence/governance
Proposal → Policy → Approval → Capability → Verify → Receipt.

### FR8 UAT
Execution, evidence, oracles, human decision, defect/retest, sign-off and release gates.

### FR9 Control plane
Static Cockpit with Journal, timelines, graph lenses, usage, provider health and causal traces.

### FR10 Supply chain
Track source → build → artifact → SBOM → attestation → promotion/deployment/release lifecycle.

### FR11 Evaluation
Per-capability outcome metrics and controlled routing feedback.

## Non-functional requirements
- local-first and offline-capable for core persistence/inspection;
- deterministic control semantics where an LLM is unnecessary;
- event replay and projection rebuildability;
- explicit idempotency and effect governance;
- no kernel dependency on a specific IDE/provider/storage adapter;
- bounded context/token usage;
- transparent unknown metrics rather than fabricated estimates;
- high testability using fakes and fault injection;
- backwards-compatible migration path from current SDDK.

## Success metrics
- provider failure recovery rate;
- percentage of operational failures resolved without Supervisor LLM call;
- mean time to understand a failed workflow from Cockpit/Journal;
- first-pass verification by capability/route;
- duplicated context/read reduction on retries;
- percentage of privileged effects with verified receipts;
- projection replay correctness;
- number of workflow packs running without kernel special cases.

## Non-goals for first releases
- replacing Git as code authority;
- building a hosted SaaS control plane;
- implementing every IDE at once;
- turning every event into autonomous agent activity;
- storing private chain-of-thought;
- using the graph as the authoritative transaction store.

