# SPEC-028 — Reactive Behaviors

**Status:** Proposed

## Purpose
Use events as the nervous system while avoiding needless LLM prompts.

## Reaction levels

### L0 OBSERVE
Persist/project only. Example: token usage sample, file read, tool started.

### L1 DETERMINISTIC
A behavior reacts without LLM. Example: retry timer, circuit breaker, join readiness, budget threshold.

### L2 COGNITIVE
Compile `OrchestratorSignal` and invoke Supervisor/critic/human because judgment is needed.

## Behavior contract

```rust
trait Behavior {
    fn subscriptions(&self) -> &[EventPattern];
    fn evaluate(&self, event: &EventEnvelope, view: &BehaviorView) -> BehaviorDecision;
}
```

`BehaviorDecision`:

```text
Ignore
Emit(events)
Issue(command)
CreateSignal(signal)
```

## Behavior families

- Runtime: retry, timeout, resume, join.
- Provider: quota, health, circuit breaker.
- Routing: route invalidation/reselection.
- Context: staleness, capsule invalidation.
- Workflow: node readiness/completion.
- Governance: policy/approval.
- Cognitive: Supervisor, Critic, Adjudicator.

## Loop safety
Every behavior invocation carries `(behavior_id, trigger_event_id, version)` idempotency. Runtime must detect pathological loops and enforce reaction depth/event budget.

## Prompt injection policy
Never concatenate arbitrary event messages directly into the supervisor prompt. Create a typed signal, compile context, then render a host-specific instruction from a trusted template.
