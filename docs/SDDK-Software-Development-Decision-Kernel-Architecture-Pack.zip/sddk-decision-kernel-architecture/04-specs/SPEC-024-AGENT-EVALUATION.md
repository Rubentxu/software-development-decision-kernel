# SPEC-024 — Agent & Routing Evaluation

**Status:** Proposed

## Goal
Measure whether agents/routes actually produce useful verified outcomes instead of optimizing only tokens or latency.

## Dataset
Golden tasks grouped by capability:
- architecture review;
- security review;
- testing plan;
- implementation;
- UAT planning;
- incident triage.

Each task defines inputs, constraints, expected properties and verifier(s), not necessarily one exact textual answer.

## Metrics
- verifier success;
- false positive/negative where definable;
- first-pass rate;
- retries;
- human corrections;
- latency;
- tokens/cost;
- context size/reuse;
- evidence completeness;
- policy violations.

## Historical routing
Production history is separate from controlled evaluation. Both can influence score, but labels distinguish benchmark vs observed real-work performance.

## Learning policy
Automatic routing changes must be explainable and bounded. Recommended:

```text
candidate score proposal
 → offline simulation
 → shadow/observe mode
 → bounded rollout
 → compare
 → promote/revert
```

## Do not optimize proxy metrics blindly
Cheapest model is not best if it causes retries; highest benchmark score is not best if tool compatibility is poor.
