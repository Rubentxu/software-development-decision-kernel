# SPEC-019 — Supervisor Runtime

**Status:** Proposed

## Purpose
Provide global cognitive coordination without turning the LLM into a scheduler.

## Responsibilities

The Supervisor MAY:
- interpret a user goal;
- select or compile a workflow;
- resolve ambiguous branches;
- replan when assumptions become invalid;
- choose among semantically different recovery strategies;
- request human input;
- invoke critic/adjudicator on high-risk decisions;
- alter priorities/budgets within policy.

The Supervisor MUST NOT directly implement:
- retries/backoff;
- locks/leases;
- queue ordering;
- timeout timers;
- provider circuit breaker state;
- event persistence;
- policy bypass;
- raw tool side effects.

## Input: OrchestratorSignal

```yaml
signal_id: sig-...
type: execution.recovery.required
severity: high
trigger_event: evt-...
workflow_run: wf-...
node_run: nr-...
reason:
  class: provider_quota_exhausted
state_summary:
  completed: []
  pending: []
alternatives:
  - route_id: route-gpt
    suitability: 0.93
constraints: []
required_decision_schema: schema://routing-decision/v1
```

## Output
Structured `SupervisorDecision` only. Natural-language rationale may accompany it, but runtime authority comes from validated structured fields.

```yaml
decision: reroute
route_id: route-gpt
confidence: 0.96
requires_human_approval: false
reason_codes:
  - current_route_unavailable
  - compatible_route_available
```

## Trigger policy
The Supervisor is invoked only when ReactionPolicy returns `COGNITIVE_SIGNAL` or a workflow node explicitly requires cognitive planning/decision.

## Delegation
Workers cannot recursively spawn arbitrary workers by default. Spawn authority belongs to Supervisor/runtime. A pack may declare a bounded `SubSupervisor` with explicit scope and budget.

## Failure
If the Supervisor model fails, it is itself an AgentExecution and therefore can be rerouted using the same Execution Router. A minimal deterministic safety policy must still support cancellation and provider failover even if no supervisor model is currently available.

## Acceptance criteria
- Supervisor decisions validate against schema.
- Same deterministic events without ambiguity do not invoke Supervisor.
- Supervisor can itself fail over providers.
- Every decision records signal, context capsule, model/route, policy hash and output hash.
