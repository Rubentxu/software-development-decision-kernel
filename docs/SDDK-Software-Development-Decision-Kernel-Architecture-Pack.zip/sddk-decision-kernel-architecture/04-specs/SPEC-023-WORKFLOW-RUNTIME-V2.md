# SPEC-023 — Workflow Runtime v2

**Status:** Proposed

## Goals
A generic, durable runtime for SDD, UAT, incidents, security, releases and future packs.

## WorkflowDefinition

```yaml
id: workflow://incident-response/v1
version: 1.0.0
inputs: schema://incident/input/v1
nodes:
  - id: triage
    kind: agent_task
    capability: incident.triage
  - id: severity_gate
    kind: decision
  - id: contain
    kind: capability
    capability: incident.contain
  - id: approval
    kind: human_approval
edges:
  - from: triage
    to: severity_gate
outputs: schema://incident/output/v1
```

## Node kinds
- `agent_task`
- `capability`
- `decision`
- `gate`
- `human_approval`
- `parallel`
- `join`
- `subworkflow`
- `wait_for_event`
- `verification`
- `compensation`

Packs may define metadata, not new kernel control semantics without an ADR.

## Runtime entities

```text
WorkflowRun
  state/version
  inputs/outputs
  correlation_id
  budget

NodeRun
  node_definition_ref
  state
  dependency state
  attempts[]

Attempt
  route
  timestamps
  outcome/error
  usage
  context_capsule_ref
```

## State transitions
All transitions are command-validated and event-emitting. Example:

```text
Pending -> Ready -> Running -> Verifying -> Succeeded
                    |             |
                    v             v
                  Waiting       Failed
```

## Durability
A process crash after an appended event must not cause an illegal duplicate side effect. Side-effect operations require idempotency keys and receipts.

## Retry semantics
Retry creates another `Attempt` within the same `NodeRun`. Workflow-level retry is distinct from provider retry.

## Pause/resume
A paused run appends an event and stops scheduling new work. Running attempts can be allowed to finish or be aborted according to policy.

## WaitForEvent
Subscriptions are expressed semantically, e.g. waiting for human approval or external CI completion. Resume occurs through canonical events.

## Compatibility
Legacy `CyclePath` becomes a compiler input, not runtime state.

## Acceptance criteria
- Three unrelated packs execute unchanged on same runtime.
- Kill/restart resumes from ledger/projections.
- Retrying provider does not duplicate NodeRun.
- Parallel/join and human wait are deterministic and testable without LLM.
