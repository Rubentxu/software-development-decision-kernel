# `sddk-sdd` Workflow

## Purpose
Preserve the original strength of SDDK while moving SDD semantics out of the generic kernel.

## Example mapping

```text
Explore → Specify → Design → Plan → Build → Verify → UAT → Review → Release → Archive
```

becomes pack-owned node IDs and labels.

```yaml
id: sdd.full
nodes:
  - { id: explore, kind: agent_task, capability: discovery.explore }
  - { id: specify, kind: agent_task, capability: requirements.specify }
  - { id: design, kind: agent_task, capability: architecture.design }
  - { id: plan, kind: agent_task, capability: planning.decompose }
  - { id: build, kind: subworkflow, workflow: implementation.build }
  - { id: verify, kind: verification }
  - { id: uat, kind: subworkflow, workflow: uat.acceptance }
  - { id: review, kind: agent_task, capability: engineering.review }
  - { id: release, kind: subworkflow, workflow: release.standard }
```

## Legacy path compiler
`AMin`, `ALite`, `AFull`, `BDirect` can map to named definitions/presets. They should not remain kernel enum branches.

## Supervisor use
The Supervisor chooses among SDD presets or compiles a tailored definition based on goal/risk; runtime executes deterministically.
