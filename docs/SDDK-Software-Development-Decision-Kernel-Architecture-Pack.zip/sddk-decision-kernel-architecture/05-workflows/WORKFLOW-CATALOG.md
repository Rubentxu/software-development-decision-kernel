# Workflow Pack Catalog

## Kernel principle
A workflow pack supplies domain-specific orchestration over the same Workflow Runtime v2.

## Initial proof set

### `sddk-sdd`
Specification-driven product/change development.

### `sddk-uat`
Human + automated acceptance validation with evidence and sign-off.

### `sddk-incident`
Triage, diagnosis, containment, remediation and post-incident verification.

If these three run without kernel special cases, the abstraction is probably healthy.

## Next packs

| Pack | Typical capabilities |
|---|---|
| `sddk-bugfix` | reproduce, diagnose, patch, verify, regression |
| `sddk-security` | threat-model, scan, investigate, remediate, review |
| `sddk-release` | readiness, provenance, gates, publish, post-verify |
| `sddk-dependency-upgrade` | impact, upgrade, build, test, compatibility |
| `sddk-db-migration` | schema plan, dry-run, backup gate, migrate, verify |
| `sddk-architecture` | discover, model, alternatives, ADR, validate |
| `sddk-research` | question, evidence gathering, synthesis, decision |

## Composition

```text
release
 ├── security.review subworkflow
 ├── uat.acceptance subworkflow
 └── supply-chain.verify subworkflow
```

Use subworkflows/capabilities rather than importing internal implementation of another pack.
