# Workflows

- [INCIDENT-WORKFLOW](INCIDENT-WORKFLOW.md) — `sddk-incident` Workflow
- [SDD-WORKFLOW](SDD-WORKFLOW.md) — `sddk-sdd` Workflow
- [UAT-WORKFLOW](UAT-WORKFLOW.md) — `sddk-uat` Workflow
- [WORKFLOW-CATALOG](WORKFLOW-CATALOG.md) — Workflow Pack Catalog
